# xG Elo Validation Summary

## Naive Baselines
- Constant 50%: Brier~0.25, Log~0.6931

## Best (k=5.0)
- acc=62.8%, brier=0.2358, log=0.6646
- Beats constant 50%: True
- Significance p=0.0000
- Elo vs xG-standings: r=0.9527, p=0.0000